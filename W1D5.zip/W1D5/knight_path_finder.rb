require_relative "01_tree_node_dup"

class KnightPathFinder

    def self.valid_moves(pos)
        
    end
    
    def initialize(pos) # [0,0]
        @root = PolyTreeNode.new(pos)  # @root.value == [0,0]
        @moves = nil
    end

    def find_path(end_pos) #[7,7]  distance = 14

    end



end