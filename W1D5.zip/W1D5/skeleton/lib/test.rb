class PolyTreeNode

    def initialize(value)
        @value = value
        @parent = nil
        @children = []
    end

    def parent
        @parent
    end

    def parent=(parent)
        @parent = parent
        parent.children << self
        true
    end

    def children
        children
    end

    def value
        value
    end

    def add_child(child)
        
    end

    # private
    attr_reader :value, :children
end