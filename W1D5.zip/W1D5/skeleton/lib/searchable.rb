class Searchable

    def initialize(root)
        @root = root
    end

    def dfs(target)
        return self if self.value == target

        self.children.each do |child|
            return self unless child.dfs(target).nil?
        end

        nil
    end

end