class PolyTreeNode

    def initialize(value)
        @value = value
        @parent = nil
        @children = []
    end

    def parent
        @parent
    end

    def parent=(parent)
        if parent == nil
            @parent = parent 
            return
        end

        unless @parent.nil?
            @parent.children.delete(self)
        end
        @parent = parent
        parent.children << self unless parent.children.include?(self)

    end

    def children
        @children
    end

    def value
        @value
    end

    def add_child(child)
        self.children << child
        child.parent = self
    end

    def remove_child(child)
        raise unless self.children.include?(child)
        self.children.delete(child)
        child.parent = nil
    end

    def dfs(target)
        return self if self.value == target

        self.children.each do |child|
            search_result = child.dfs(target)
            return search_result unless search_result == nil
        end

        nil
    end

    def bfs(target)
        queue = [self]

        until queue.empty? 
            return queue[0] if queue[0].value == target
            queue[0].children.each { |child| queue << child }
            queue.shift
        end

        nil
    end

    # def inspect
    #     children = self.children.map {|child| child.value}
    #     return "<Parent: #{self.parent.value}, Children: #{children}>" unless self.parent.nil?
    #     return "<Parent: #{self.parent}, Children: #{children}>"
        
    # end
         

end

# a = PolyTreeNode.new("A")
# b = PolyTreeNode.new("B")
# c = PolyTreeNode.new("C")
# d = PolyTreeNode.new("D")
# e = PolyTreeNode.new("E")
# f = PolyTreeNode.new("F")
# load "lib/00_tree_node.rb"